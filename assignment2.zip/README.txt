Instructions

Part1:
python ass2p1FINAL.py

Part2:
python ass2p2FINAL.py

Part3:
python ass2p3FINAL.py

Follow instructions by inserting file name (.txt) and quantum if asked